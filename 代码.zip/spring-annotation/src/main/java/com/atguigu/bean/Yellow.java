package com.atguigu.bean;

public class Yellow {

}
