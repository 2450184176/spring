package com.atguigu.bean;

public class RainBow {

}
