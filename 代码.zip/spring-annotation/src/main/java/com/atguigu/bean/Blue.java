package com.atguigu.bean;

public class Blue {
	
	public Blue(){
		System.out.println("blue...constructor");
	}
	
	public void init(){
		System.out.println("blue...init...");
	}
	
	public void detory(){
		System.out.println("blue...detory...");
	}
	
	

}
